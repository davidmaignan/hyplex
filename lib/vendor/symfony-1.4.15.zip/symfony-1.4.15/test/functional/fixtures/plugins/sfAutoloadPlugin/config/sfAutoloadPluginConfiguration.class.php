<?php

class sfAutoloadPluginConfiguration extends sfPluginConfiguration
{
}
