<?php

/**
 * configViewHasLayout actions.
 *
 * @package    project
 * @subpackage configViewHasLayout
 * @author     Fabien Potencier <fabien.potencier@symfony-project.com>
 * @version    SVN: $Id: actions.class.php 2288 2006-10-02 15:22:13Z fabien $
 */
class configViewHasLayoutActions extends sfActions
{
  public function executeWithoutLayout()
  {
  }
}
