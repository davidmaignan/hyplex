Configration Steps


#1) Create a folder (Say IPTOCountry) in your root web directory

#2) Place both "CountryFromIP.inc.php" and "Example.php" files in new created folder.

#3) Unzip all the images from the flag.zip in the  "<New Folder Name>/Flags/"  folder (download flag.zip from the provided link   ie.   http://www.geocities.com/rochakchauhan/flag.zip)

#4) Create one "CountryIPDatabase.txt" file from all 5 text files to create a single Country-IP Database.

#5) Now run example.php



GUD LUCK 

Rochak.